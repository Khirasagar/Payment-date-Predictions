package com.backend;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/DeleteRow")
public class DeleteRow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public DeleteRow() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
	
			
			String sl_no = request.getParameter("sl_no");
				
			
			Connection conn = MySQLConnection.getConn();

			String query = "DELETE FROM winter_internship WHERE sl_no=?";
			
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, sl_no);
			ps.executeUpdate();
			
			conn.close();
					
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
