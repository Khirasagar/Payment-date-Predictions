package com.backend;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/AddRow")
public class AddRow extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public AddRow() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			
			
			
			POJO data = new POJO();

			

			data.setBusiness_code(request.getParameter("business_code"));   
			data.setCust_number(request.getParameter("cust_number"));   
			data.setClear_date(request.getParameter("clear_date"));   
			data.setBuisness_year(Integer.parseInt(request.getParameter("buisness_year")));   
			data.setDoc_id(request.getParameter("doc_id"));   
			data.setPosting_date(request.getParameter("posting_date"));   
			data.setDocument_create_date(request.getParameter("document_create_date"));   
			data.setDue_in_date(request.getParameter("due_in_date"));   
			data.setInvoice_currency(request.getParameter("invoice_currency"));   
			data.setDocument_type(request.getParameter("document_type"));   
			data.setPosting_id(Integer.parseInt(request.getParameter("posting_id")));   
			data.setTotal_open_amount(request.getParameter("total_open_amount"));   
			data.setBaseline_create_date(request.getParameter("baseline_create_date"));   
			data.setCust_payment_terms(request.getParameter("cust_payment_terms"));   
			data.setInvoice_id(request.getParameter("invoice_id"));   
			
			Connection conn = MySQLConnection.getConn();
			String query = "INSERT INTO winter_internship (business_code, cust_number, clear_date, buisness_year, doc_id, posting_date, document_create_date, due_in_date, invoice_currency, document_type, posting_id, total_open_amount, baseline_create_date, cust_payment_terms, invoice_id) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement ps = conn.prepareStatement(query);
			
			
			
			ps.setString(1, data.getBusiness_code());
			ps.setString(2, data.getCust_number());
			ps.setString(3, data.getClear_date());
			ps.setInt(4, data.getBuisness_year());
			ps.setString(5, data.getDoc_id());
			ps.setString(6, data.getPosting_date());
			ps.setString(7, data.getDocument_create_date());
			ps.setString(8, data.getDue_in_date());
			ps.setString(9, data.getInvoice_currency());
			ps.setString(10, data.getDocument_type());
			ps.setInt(11, data.getPosting_id());
			ps.setString(12, data.getTotal_open_amount());
			ps.setString(13, data.getBaseline_create_date());
			ps.setString(14, data.getCust_payment_terms());
			ps.setString(15, data.getInvoice_id());
			
			ps.executeUpdate();
			conn.close();
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
